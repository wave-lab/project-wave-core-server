module.exports = {
    FAIL : '실패',
    SUCCESS : '성공',

    NULL_VALUE: "필요한 값이 없습니다",
    OUT_OF_VALUE: "파라미터 값이 잘못되었습니다",

    SIGNIN_SUCCESS: "로그인 성공",
    SIGNIN_FAIL: "로그인 실패",
    NOT_CORRECT_USERINFO: "Email 혹은 비밀번호가 일치하지 않습니다",
    SIGNUP_SUCCESS: "회원가입 성공",
    SIGNUP_FAIL: "회원가입 실패",

    SEND_EMAIL: "이메일 전송 성공",
    SEND_EMAIL_FAIL: "이메일 전송 실패",
    DUPLICATED_EMAIL_FAIL: "중복된 email이 있습니다.",
    EMAIL_CHECK_SUCCESS: "email 중복 검사 완료",

    DUPLICATED_NICKNAME_FAIL: "중복된 nickname이 있습니다.",
    NICKNAME_CHECK_SUCCESS: "nickname 중복 검사 완료",

    AUTHENTICATION_SAME: "인증번호 일치",
    AUTHENTICATION_FALSE: "인증번호 불일치",

    GENRE_INSERT_FAIL: "장르 저장 실패",
    MOOD_INSERT_FAIL: "분위기 저장 실패",
    ARTIST_INSERT_FAIL: "선호 아티스트 저장 실패",

    MYPAGE_SUCCESS: "마이페이지 조회 성공",
    MYPAGE_EDIT_FAIL: "마이페이지 수정 실패",
    MYPAGE_EDIT_SUCCESS: "마이페이지 수정 성공",
    NOT_EXIST_USER: "존재하지 않는 회원입니다.",

    INVALID_TOKEN: "잘못된 형식의 토큰입니다.",
    EMPTY_TOKEN: "토큰값이 존재하지 않습니다.",
    EXPRIED_TOKEN: "만료된 토큰입니다.",
    CREATE_TOKEN: "토큰 발급 완료.",
    NOT_CORRECT_TOKEN_USER: "토큰과 일치하는 유저가 없습니다.",

    NO_SELECT_AUTHORITY: "조회 권한 없음.",
    USER_SELECTED: "회원 조회 성공."
}
