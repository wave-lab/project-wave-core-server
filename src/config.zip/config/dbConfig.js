const mysql = require('promise-mysql');

const dbConfig = {
    host: 'sopt24server.cfk3nxeoar1v.ap-northeast-2.rds.amazonaws.com',
    port: 3306,
    user: 'jinee0717',
    password: 'k1207417',
    database: 'project-wave',
    connectionLimit: 100,
    waitForConnection : true
}

module.exports = mysql.createPool(dbConfig);