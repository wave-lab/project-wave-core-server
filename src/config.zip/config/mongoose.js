const mongoose = require('mongoose');
mongoose.Promise = global.Promise;

module.exports = () => {
    function connect() {
        mongoose.connect('mongodb://wave:wave0630@15.164.70.24:27017/project-wave', { useNewUrlParser: true }, (err) => {
            if (err) {
                console.error('mongodb connection error', err);
            } else {
                console.log('mongodb connected');
            }
        });
    }
    connect();
    mongoose.connection.on('disconnected', connect);
};