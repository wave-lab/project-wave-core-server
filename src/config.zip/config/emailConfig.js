module.exports = {
    emailConfig : {
        mailer: {
            service: 'Gmail',
            host: 'localhost',
            port: '465',
            user: 'wave.studio.beta@gmail.com',
            password: 'wave0713!',
        }
    }
};